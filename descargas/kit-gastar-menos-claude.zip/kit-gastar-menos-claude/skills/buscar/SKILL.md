---
name: buscar
description: Cómo buscar en internet sin gastar de más (precios, compras, comparativas, noticias, datos, "cuál es mejor", "dónde lo compro"). Usar SIEMPRE antes de cualquier búsqueda web, y cuando diga "busca", "mira en internet", "investiga", "compárame", "qué me compro", "cuánto cuesta" o "encuéntrame".
---

# Buscar

Buscar en internet es lo más caro que haces: cada página abierta son 10-30k tokens. La referencia de lo que no se repite: 16 agentes y 3,5M de tokens para encontrar 4 piezas de coche. Hecho así, en este hilo, son unos 150k.

## Antes de buscar
1. Di en una frase qué hay que encontrar y qué dato lo decide (precio, compatibilidad, fecha, existencias).
2. Si falta algo que cambia la búsqueda (país, presupuesto, el modelo exacto que ya tengo), míralo primero en tu memoria y en lo que hayamos hablado. Si no está, pregúntalo en una línea antes de buscar.
3. Sin agentes. Todo en este hilo.

## La ronda
1. De 3 a 6 búsquedas lanzadas a la vez, en la misma tanda, cada una con un ángulo distinto: el nombre exacto, la tienda o el fabricante, "precio" u "opiniones", y en inglés si es un producto internacional.
2. Modo normal. El ampliado solo si la normal sale pobre o vieja, o desde el principio para precios y existencias, algo de esta misma semana o algo muy de nicho, y entonces en una o dos búsquedas, no en todas.
3. Abre como mucho 3 páginas, solo las que dan el dato: la tienda o el fabricante, la ficha técnica, una comparativa seria. Con el navegador, saca el texto de la página en vez de hacer capturas.
4. Mira la fecha de cada fuente. Un precio de hace más de tres meses se da como "a fecha de...".

## Parar
- En cuanto el dato está con fuente y fecha, paras. No busques para confirmar lo que ya está confirmado.
- Si la ronda no lo resuelve, dime qué falta y propón una segunda ronda de 3 búsquedas como mucho. No la lances sin decírmelo.

## Entregar
- La respuesta primero, en una o dos líneas.
- En compras: precio, tienda, envío a mi país, plazo y enlace. Si comparas tres opciones o más con los mismos datos, una tabla; si no, en frases.
- Comprueba que es compatible con lo que ya tengo y dilo en una línea.
- Recomienda una opción y di por qué en media línea.
- Al final, las fuentes con su enlace.

## Si de verdad hacen falta agentes
Solo si escribo un tope (+300k, por ejemplo) o te digo que sí después de proponérmelo. Entonces: como mucho 5 búsquedas y 3 páginas por agente, escrito en su encargo; modelo sonnet; y sin segunda vuelta de comprobación con el modelo grande salvo que la pida.
