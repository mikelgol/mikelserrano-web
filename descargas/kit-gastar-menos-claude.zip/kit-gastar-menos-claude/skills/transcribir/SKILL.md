---
name: transcribir
description: Pasa a texto un reel, un TikTok, un Short, un vídeo de YouTube, un Loom público o un fichero de audio o vídeo, en el propio ordenador y sin subirlo a ningún sitio. Usar cuando diga "transcribe", "qué dice este vídeo", "sácame el texto", "pásalo a texto" o mande un enlace de un vídeo o un audio pidiendo lo que dice.
---

# Transcribir

1. Ejecuta, con el Python del kit (está en la sección Equipo de CLAUDE.md: ~/.claude/kit-python/Scripts/python.exe en Windows, ~/.claude/kit-python/bin/python en Mac):

   "<python del kit>" "<carpeta de esta skill>/transcribir.py" "<enlace o fichero>" [idioma]

   - El idioma por defecto es es. "auto" lo detecta; también vale en, pt, fr...
   - Si es largo o va lento, añade --modelo small: más rápido y algo peor.
2. Un reel de un minuto tarda unos 20-40 segundos. La primera vez baja el modelo (1,6 GB) y tarda más.
3. Devuélveme el texto tal cual. Si te pido un resumen o lo que importa, hazlo sobre ese texto, sin volver a transcribir.
4. Si no puede descargar el enlace (Instagram a veces pide sesión), dime en una línea que lo descargue yo y te pase el fichero.
5. La copia queda en ~/Transcripciones/. Si el vídeo pasa de 20 minutos, activa antes la skill pc-despierto.
