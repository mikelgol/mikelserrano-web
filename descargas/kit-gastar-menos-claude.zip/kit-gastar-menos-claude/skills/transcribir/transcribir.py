#!/usr/bin/env python3
"""transcribir: pasa a texto un reel, un TikTok, un Short, un vídeo de YouTube, un Loom público o un fichero de audio o vídeo.

Uso: python transcribir.py <enlace o fichero> [idioma] [--modelo large-v3-turbo|medium|small]
Idioma por defecto: es. Con "auto" lo detecta. Imprime el texto y deja una copia en ~/Transcripciones/.
Todo pasa en este ordenador: el vídeo no se sube a ningún sitio.
Necesita en este Python: faster-whisper, yt-dlp e imageio-ffmpeg (trae su propio ffmpeg; si hay otro instalado, usa ese).
"""
import argparse
import os
import re
import shutil
import subprocess
import sys
import tempfile
import time
from pathlib import Path

SALIDA = Path.home() / "Transcripciones"


def ytdlp():
    try:
        import yt_dlp  # noqa: F401
        return [sys.executable, "-m", "yt_dlp"]
    except ImportError:
        exe = shutil.which("yt-dlp")
        if exe:
            return [exe]
        sys.exit("Falta yt-dlp: instálalo en este Python con «-m pip install yt-dlp».")


def ffmpeg():
    exe = shutil.which("ffmpeg")
    if exe:
        return exe
    try:
        import imageio_ffmpeg
        return imageio_ffmpeg.get_ffmpeg_exe()
    except Exception:
        sys.exit("Falta ffmpeg: instálalo en este Python con «-m pip install imageio-ffmpeg».")


def descargar(url, carpeta):
    base = ytdlp() + ["-q", "--no-warnings", "--no-playlist", "-f", "ba/b", "-o", str(carpeta / "%(id)s.%(ext)s")]
    # Algunas redes piden sesión: se reintenta con las cookies del navegador. En Windows, Chrome y Edge
    # no dejan sacarlas (cifrado de la app); Firefox sí.
    navegadores = ["chrome", "safari"] if sys.platform == "darwin" else ["firefox", "edge", "chrome"]
    for extra in [[]] + [["--cookies-from-browser", n] for n in navegadores]:
        r = subprocess.run(base + extra + [url], capture_output=True, text=True)
        hechos = [f for f in carpeta.iterdir() if f.is_file() and not f.name.endswith((".part", ".ytdl"))]
        if r.returncode == 0 and hechos:
            return hechos[0]
        for f in carpeta.iterdir():
            if f.is_file():
                f.unlink()
    sys.exit(f"No he podido descargar {url}. Si pide iniciar sesión, descárgalo tú y pásame el fichero.")


def leer_audio(media):
    """El audio a 16 kHz y mono, leído con ffmpeg y en memoria. Whisper no usa así su propio lector (PyAV),
    que falla con las versiones nuevas de PyAV."""
    import numpy as np
    r = subprocess.run([ffmpeg(), "-nostdin", "-v", "error", "-i", str(media), "-vn", "-ac", "1", "-ar", "16000",
                        "-f", "s16le", "-"], capture_output=True)
    if r.returncode != 0 or not r.stdout:
        sys.exit("Ese fichero no tiene audio o no se puede leer.")
    return np.frombuffer(r.stdout, np.int16).astype(np.float32) / 32768.0


def transcribir(audio, idioma, modelo):
    try:
        from faster_whisper import WhisperModel
    except ImportError:
        sys.exit("Falta faster-whisper: instálalo en este Python con «-m pip install faster-whisper».")
    hilos = max(1, min(8, os.cpu_count() or 4))
    m = WhisperModel(modelo, device="auto", compute_type="int8", cpu_threads=hilos)
    segmentos, info = m.transcribe(audio, language=None if idioma == "auto" else idioma, vad_filter=True)
    lineas = [s.text.strip() for s in segmentos if s.text.strip()]
    return "\n".join(lineas), info


def main():
    try:
        sys.stdout.reconfigure(encoding="utf-8")
        sys.stderr.reconfigure(encoding="utf-8")
    except (AttributeError, ValueError):
        pass
    p = argparse.ArgumentParser(description="Pasa a texto un vídeo o un audio, en este ordenador.")
    p.add_argument("entrada", help="enlace (reel, TikTok, YouTube, Loom público) o fichero de audio o vídeo")
    p.add_argument("idioma", nargs="?", default="es", help='es por defecto; "auto" para detectarlo')
    p.add_argument("--modelo", default="large-v3-turbo",
                   help="large-v3-turbo (por defecto), medium o small (más rápido y algo peor)")
    a = p.parse_args()
    t = time.time()
    with tempfile.TemporaryDirectory(prefix="transcribir_") as tmp:
        if re.match(r"https?://", a.entrada):
            media = descargar(a.entrada, Path(tmp))
        else:
            media = Path(a.entrada).expanduser()
            if not media.is_file():
                sys.exit(f"No existe {media}")
        audio = leer_audio(media)
    texto, info = transcribir(audio, a.idioma, a.modelo)
    if not texto:
        sys.exit("No he oído nada que transcribir.")
    SALIDA.mkdir(parents=True, exist_ok=True)
    destino = SALIDA / f"{media.stem}.txt"
    destino.write_text(texto + "\n", encoding="utf-8")
    print(texto)
    print(f"\n[{info.duration:.0f} s de audio en {time.time() - t:.0f} s, idioma {info.language}] Guardado en {destino}")


if __name__ == "__main__":
    main()
