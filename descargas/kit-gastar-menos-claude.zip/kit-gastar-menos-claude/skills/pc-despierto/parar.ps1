# Corta el despierto.ps1 que esté corriendo. Al cerrarse, Windows vuelve solo a su ahorro de energía normal.
$fichero = Join-Path $env:TEMP 'pc-despierto.pid'
if (Test-Path $fichero) {
    Stop-Process -Id ([int](Get-Content $fichero)) -ErrorAction SilentlyContinue
    Remove-Item -Path $fichero -ErrorAction SilentlyContinue
    'Parado: el PC ya puede suspenderse.'
}
else {
    'No estaba activado.'
}
