param([double]$Horas = 3)
# Mantiene Windows despierto (sistema y pantalla) mientras corre. Al terminar el tiempo, o al pararlo con
# parar.ps1, Windows vuelve a su ahorro de energía normal. No cambia ningún ajuste del sistema.
$Horas = [Math]::Min([Math]::Max($Horas, 0.01), 8)
$fichero = Join-Path $env:TEMP 'pc-despierto.pid'
Set-Content -Path $fichero -Value $PID
Add-Type -Namespace KitClaude -Name Energia -MemberDefinition '[DllImport("kernel32.dll")] public static extern uint SetThreadExecutionState(uint esFlags);'
# 2147483651 = ES_CONTINUOUS | ES_SYSTEM_REQUIRED | ES_DISPLAY_REQUIRED
[void][KitClaude.Energia]::SetThreadExecutionState([uint32]2147483651)
try {
    Start-Sleep -Seconds ([int]($Horas * 3600))
}
finally {
    # 2147483648 = ES_CONTINUOUS: deja de pedir que siga despierto
    [void][KitClaude.Energia]::SetThreadExecutionState([uint32]2147483648)
    Remove-Item -Path $fichero -ErrorAction SilentlyContinue
}
