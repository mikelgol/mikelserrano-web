---
name: pc-despierto
description: Mantiene el ordenador despierto (sistema y pantalla) mientras corre una tarea larga, para que no se suspenda a mitad. Usar cuando diga "no te apagues", "que no se suspenda", "que siga aunque me vaya" o "mantén el PC despierto", y antes de lanzar algo que vaya a durar más que la respuesta (descargas grandes, instalaciones, transcripciones largas).
---

# PC despierto

## Windows
1. En segundo plano:

   powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "<carpeta de esta skill>/despierto.ps1" -Horas 3

2. Son 3 horas. Si va a durar más, sube -Horas (8 como mucho). Al acabar el tiempo vuelve solo a lo normal.
3. Para cortarlo antes:

   powershell.exe -NoProfile -ExecutionPolicy Bypass -File "<carpeta de esta skill>/parar.ps1"

## Mac
1. En segundo plano: caffeinate -dimsu -t 10800 (3 horas). Nunca sin -t, o no vuelve a dormir.
2. Para cortarlo antes: pkill caffeinate

## En los dos
- Si estás en la app de escritorio y tiene la opción de mantener el ordenador despierto, actívala también.
- Dímelo en una línea: activado y cuántas horas. En un portátil, enchufado y con la tapa abierta.
