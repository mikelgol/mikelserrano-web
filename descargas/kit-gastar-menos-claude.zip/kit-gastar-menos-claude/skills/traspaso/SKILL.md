---
name: traspaso
description: Deja un traspaso de 5 líneas para seguir el trabajo en un chat limpio sin perder nada. Usar cuando diga "traspaso", "voy a hacer clear", "pásalo a un chat nuevo" o "esto se ha hecho largo", y proponerlo tú cuando cambiemos de tema, cuando el contexto pase de la mitad o después de dos intentos fallidos con lo mismo.
---

# Traspaso

Con /clear se empieza de cero y gasta mucho menos en cada mensaje. /compact resume, pero arrastra también las pistas malas. El traspaso es lo que se pega en el chat nuevo para seguir donde estábamos.

1. Si algo importante solo está en el chat (una decisión, un dato que te he dado), guárdalo antes en tu memoria o en el fichero que toque.
2. Escribe el traspaso en un bloque para copiar, en 5 líneas:
   - Objetivo: qué estamos haciendo y para qué.
   - Hecho: lo terminado, con los ficheros o enlaces que importan.
   - Decidido: lo que ya está decidido y no hay que volver a discutir.
   - Falta: el siguiente paso concreto.
   - Ojo: lo que falló o lo que no hay que repetir.
3. Dime solo: "Haz /clear y pega esto."

Cuándo proponerlo tú, en una línea y sin hacerlo solo:
- Cambiamos de tema.
- El contexto pasa de la mitad (míralo con /context si lo tienes).
- Llevamos dos intentos fallidos con lo mismo: un chat limpio sale mejor que seguir dando vueltas.
