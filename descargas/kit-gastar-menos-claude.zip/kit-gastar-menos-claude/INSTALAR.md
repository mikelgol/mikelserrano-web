# Instala este kit en mi Claude Code

Eres mi Claude Code. Esta carpeta trae reglas, ajustes y skills para que gastes menos, busques mejor y hagas más cosas tú solo. Instálalo en mi configuración de usuario, ~/.claude/, para que valga en cualquier carpeta desde la que te abra.

Cómo trabajas:
1. Lo haces tú de principio a fin, en este hilo y sin agentes. Me dices en una línea lo que vas haciendo y no me preguntas si sigues.
2. Solo me hablas para lo que no puedes hacer tú: iniciar sesión, escribir una contraseña o aceptar un permiso o un aviso de Windows. Me dices qué hago en una frase y esperas a mi "listo".
3. Antes de cambiar nada, copias mi ~/.claude/CLAUDE.md y mi ~/.claude/settings.json, si existen, a ~/.claude/copia-antes-del-kit/.
4. Lo que ya tenga se fusiona, no se pisa. Lee cada fichero antes de escribir en él.
5. Si un paso no sale, lo apuntas y sigues con el siguiente. Cada paso acaba con su comprobación: si no la pasa, no está hecho.
6. Está pensado para Windows, donde Claude Code trabaja con Git Bash, y vale igual en Mac. Adapta los comandos al sistema que haya.

## 1. Qué hay
Mira la versión con claude --version y actualiza con claude update si se puede. Mira el sistema y qué hay ya en ~/.claude/ (CLAUDE.md, settings.json y skills/).

Comprobación: dime en una línea el sistema, la versión y lo que había.

## 2. Reglas
Si no existe ~/.claude/CLAUDE.md, copia el CLAUDE.md de esta carpeta. Si existe, añade lo de esta carpeta sin duplicar lo que ya diga, y si algo choca, déjalo como estaba y dímelo. La sección Equipo del final la rellenas en el paso 5.

Comprobación: cuántas líneas tiene ahora ~/.claude/CLAUDE.md. Si pasa de 150, dime qué sobra.

## 3. Ajustes
Fusiona el settings.json de esta carpeta con ~/.claude/settings.json sin borrar nada de lo que haya. Si había "ultracode": true o "fastMode": true, quítalo y dímelo. Pregúntame mi plan: si es Pro, añade "model": "sonnet"; en Max o Ultra se queda el de serie.

Comprobación: que el JSON sea válido. Si todavía no hay Python ni node para comprobarlo, lo compruebas al final del paso 5.

## 4. Skills
Copia las cuatro carpetas de skills/ (buscar, traspaso, transcribir y pc-despierto) a ~/.claude/skills/. Si ya hay una con el mismo nombre, compáralas y pregúntame antes de pisarla.

Comprobación: lista lo que hay en ~/.claude/skills/.

## 5. Python, transcribir y el filtro de bash
1. Mira si hay Python 3 de verdad con python --version o py -3 --version. En Windows, el "python" que solo abre la Microsoft Store no cuenta.
2. Si no hay, instálalo: en Windows, winget install -e --id Python.Python.3.12 --scope user; en Mac, brew install python. Si pide aceptar condiciones o permisos de administrador, dame el comando para que lo pegue yo en PowerShell (o en la Terminal del Mac) y espera. Si después no lo encuentras, en Windows está en %LOCALAPPDATA%\Programs\Python\.
3. Crea el Python del kit con python -m venv ~/.claude/kit-python e instala dentro faster-whisper, yt-dlp e imageio-ffmpeg con su propio pip: ~/.claude/kit-python/Scripts/python.exe -m pip install faster-whisper yt-dlp imageio-ffmpeg en Windows, o ~/.claude/kit-python/bin/python en Mac. imageio-ffmpeg trae su propio ffmpeg, así que no hace falta instalar otro.
4. Copia hooks/revisa-bash.py a ~/.claude/hooks/ y añade esto a ~/.claude/settings.json, fusionado con lo que haya, con rutas absolutas y barras normales (C:/Users/...):

   "hooks": {"PreToolUse": [{"matcher": "Bash", "hooks": [{"type": "command", "command": "\"<python del kit>\" \"<ruta de revisa-bash.py>\"", "timeout": 5}]}]}

5. Rellena la sección Equipo de ~/.claude/CLAUDE.md: sistema, terminal y la ruta del Python del kit.

Comprobación:
- El filtro, con los dos ficheros de prueba de la carpeta hooks/ de este kit: "<python del kit>" ~/.claude/hooks/revisa-bash.py < hooks/prueba-mala.json tiene que salir con código 2, y con prueba-buena.json, con 0. Si no, quita el hook de los ajustes y dímelo. No escribas el ejemplo malo dentro de un comando: el propio filtro lo bloquea.
- Transcribir: con la skill transcribir, un vídeo corto y público (un Short de YouTube, por ejemplo). Enséñame las dos primeras frases. La primera vez baja el modelo, 1,6 GB.
- Que ~/.claude/settings.json sea JSON válido.

## 6. PC despierto
Comprobación: lanza la skill pc-despierto con -Horas 0.01 (en Mac, caffeinate con -t 5), mira que arranca sin errores y que parar.ps1 lo corta.

## 7. Chrome
Si Chrome no está instalado, dímelo. Instala la extensión Claude in Chrome y conéctala con Claude Code siguiendo https://code.claude.com/docs/es/chrome. Iniciar sesión en la extensión con mi cuenta de Claude lo hago yo.

Comprobación, después de reiniciar: abre una web en una pestaña nueva y dime su título.

## 8. Control del ordenador
Va en la app de escritorio de Claude. Si no la tengo, dime que la baje de https://claude.com/download. Dime dónde se activa en sus ajustes; si no aparece, es que la app no está al día o mi plan no lo trae: lo apuntas y sigues.

Comprobación, después de reiniciar: haz una captura y dime qué programas tengo abiertos.

## 9. Conectores y correo
Mira qué conectores tengo con claude mcp list o /mcp. Gmail, Google Drive, Google Calendar y Notion van con mi cuenta de Claude: si ya están conectados en claude.ai, aquí salen solos. Si falta alguno, dime que lo conecte en https://claude.ai/customize/connectors y espera.

Comprobación, después de reiniciar: una lectura de cada uno (el último correo, el último archivo de Drive, los próximos eventos y la última página de Notion). Solo leer: nada de enviar ni cambiar.

## Al acabar
Dame una lista corta con cada paso, hecho o pendiente, y lo que falta por mi parte. Dime que cierre y abra Claude Code, porque Chrome, el control del ordenador, los conectores y el filtro se cargan al reiniciar, y qué escribirte al volver para hacer las comprobaciones que quedan.
