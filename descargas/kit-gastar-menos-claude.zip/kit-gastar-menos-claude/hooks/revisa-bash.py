#!/usr/bin/env python3
"""Hook PreToolUse de Bash: bloquea funciones de shell que se llaman a sí mismas.
Mira el comando y los .sh que ejecuta. Si este script falla, deja pasar: nunca bloquea por error propio.
Sale de un fallo real: una función con nombre de comando que se llamaba a sí misma lanzó 358 procesos y colgó un Mac dos veces."""
import json
import os
import re
import sys

DEF = re.compile(r"(?:^|[\s;{(&|])(?:function\s+([A-Za-z_][\w-]*)\s*(?:\(\)\s*)?|([A-Za-z_][\w-]*)\s*\(\)\s*)\{")


def cuerpo(texto, inicio):
    prof, i = 1, inicio
    while i < len(texto) and prof:
        prof += {"{": 1, "}": -1}.get(texto[i], 0)
        i += 1
    return texto[inicio:i]


def recursivas(texto):
    halladas = set()
    for m in DEF.finditer(texto):
        nombre = m.group(1) or m.group(2)
        llamada = re.compile(
            r"(?:^|[;&|({]|\bthen\b|\bdo\b|\belse\b|\$\()\s*" + re.escape(nombre) + r"(?=\s|$|[;|&)])",
            re.M,
        )
        if llamada.search(cuerpo(texto, m.end())):
            halladas.add(nombre)
    return halladas


def scripts(cmd, cwd):
    variables = dict(re.findall(r"(?:^|[\s;])([A-Za-z_]\w*)=([^\s;]+)", cmd))
    for ruta in re.findall(r"[^\s\"'=;|&()<>]+\.(?:sh|bash|zsh)\b", cmd):
        for _ in range(3):
            ruta = re.sub(r"\$\{?(\w+)\}?", lambda v: variables.get(v.group(1), v.group(0)), ruta)
        ruta = os.path.join(cwd, os.path.expanduser(ruta))
        if os.path.isfile(ruta) and os.path.getsize(ruta) < 500_000:
            yield ruta


def main():
    entrada = json.load(sys.stdin)
    cmd = entrada.get("tool_input", {}).get("command", "")
    cwd = entrada.get("cwd") or os.getcwd()
    malas = recursivas(cmd)
    for ruta in scripts(cmd, cwd):
        malas |= recursivas(open(ruta, errors="replace").read())
    if malas:
        print(
            f"Bloqueado: la función {', '.join(sorted(malas))} se llama a sí misma y puede colgar el ordenador. "
            "Si querías el comando del sistema, cambia el nombre de la función o usa `command <nombre>`.",
            file=sys.stderr,
        )
        sys.exit(2)


if __name__ == "__main__":
    try:
        main()
    except SystemExit:
        raise
    except Exception:
        sys.exit(0)
